<div class="container-fluid d-flex justify-content-center">

  <div class="row mt-5">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-4 mt-3">
      <div class="card">
        <img src="<?php echo e(asset($product->image)); ?>" class="card-img-top" width="100%">
        <div class="card-body pt-0 px-0">
          <div class="d-flex flex-row justify-content-between mt-1 px-3">
            <h5><?php echo e($product->name); ?></h5>
          </div>
          <div class="d-flex flex-row justify-content-between px-3">
            <p><?php echo e(\Str::limit($product->description, 110)); ?></p>
          </div>
          <hr class="mt-2 mx-3">
          <div class="d-flex flex-row justify-content-between mb-0 px-3">
            <small class="text-muted mt-1">SKU</small>
            <h6><?php echo e($product->SKU); ?></h6>
          </div>
          <div class="d-flex flex-row justify-content-between p-3 mid">
            <div class="d-flex flex-column">
              <small class="text-muted mb-2">Retail Price</small>
              <div class="d-flex flex-row">
                <h5 class="ml-1"><s>₹ <?php echo e($product->retail_price); ?></s></h5>
              </div>
            </div>
            <div class="d-flex flex-column">
              <small class="text-muted mb-2">Our Price</small>
              <div class="d-flex flex-row">
                <h5 class="ml-1">₹ <?php echo e($product->our_price); ?></h5>
              </div>
            </div>
          </div>
          <div class="mx-3 mt-3 mb-1">
            <button type="button" class="btn btn-danger btn-block cart" data-product_id="<?php echo e($product->id); ?>"><small>Add to
                Cart</small></button>
          </div>
        </div>
        <div class="mx-3 mb-1" id="flash-messages-<?php echo e($product->id); ?>"></div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="d-flex flex-row justify-content-between mt-3 px-3">
      <?php echo e($products->links()); ?>

    </div>
  </div>
</div><?php /**PATH D:\wamp64\www\hima-practical-test\resources\views/products/product-list.blade.php ENDPATH**/ ?>