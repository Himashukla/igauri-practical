<?php $total = 0; ?>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row border-bottom">
  <div class="row main align-items-center">
    <div class="col-2"><img class="img-fluid" src="<?php echo e($product->image); ?>"></div>
    <div class="col">
      <div class="row text-muted"><small><?php echo e($product->SKU); ?></small></div>
      <h6 class="row"><?php echo e($product->name); ?></h6>
    </div>
    <div class="col">
      <a class="quantity" data-type="minus" data-product_id="<?php echo e($product->id); ?>">-</a>
      <a href="#" class="border"><?php echo e($quantity[$key]); ?></a>
      <a class="quantity" data-type="plus" data-product_id="<?php echo e($product->id); ?>">+</a>
    </div>
    <div class="col">₹ <?php echo e($product->our_price); ?></div>
    <?php $total += $subTotal = $quantity[$key] * $product->our_price; ?>
    <div class="col">₹ <?php echo e($subTotal); ?>

      <span class="close">&#10005;</span>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\wamp64\www\hima-practical-test\resources\views/products/cart-table.blade.php ENDPATH**/ ?>